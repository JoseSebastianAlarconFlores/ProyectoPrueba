# Sistema de Monitoreo de Red Interna II-25

Aplicación web Flask para monitoreo de red interna, incluyendo gestión de usuarios, dispositivos, alertas, eventos, reportes y notificaciones, conectada a base de datos MySQL.

## Características

- Gestión de usuarios con login y CRUD.
- Monitoreo de dispositivos en la red.
- Sistema de alertas y notificaciones.
- Generación de reportes.
- Roles y permisos para usuarios.

## Requisitos

- Python 3.8 o superior
- MySQL Server
- Git

## Instalación

1. Clona el repositorio:
   ```
   git clone https://github.com/danielruiz1208/SI---SISTEMA-DE-MONITOREO-DE-RED-INTERNA-II-25.git
   cd SI---SISTEMA-DE-MONITOREO-DE-RED-INTERNA-II-25
   ```

2. Crea un entorno virtual:
   ```
   python -m venv venv
   source venv/bin/activate  # En Windows: venv\Scripts\activate
   ```

3. Instala las dependencias:
   ```
   pip install -r requirements.txt
   ```

4. Configura la base de datos:
   - Crea una base de datos MySQL llamada `base_monitoreo`.
   - Importa las tablas necesarias (usuarios, roles, dispositivos, alertas, etc.).
   - Crea un archivo `.env` en la raíz del proyecto con:
     ```
     DB_HOST=localhost
     DB_USER=tu_usuario
     DB_PASSWORD=tu_contraseña
     DB_NAME=base_monitoreo
     SECRET_KEY=una_clave_secreta_segura
     ```

5. Ejecuta la aplicación:
   ```
   python run.py
   ```
   Accede en `http://localhost:5000` (o el puerto configurado).

## Uso

- Inicia sesión con un usuario existente.
- Gestiona usuarios, dispositivos, alertas y reportes desde la interfaz web.

## Estructura del Proyecto

- `app/`: Código de la aplicación Flask.
- `app/models/`: Modelos de base de datos (usuarios, dispositivos, alertas, etc.).
- `app/controllers/`: Controladores de rutas.
- `app/services/`: Lógica de negocio.
- `app/templates/`: Plantillas HTML.
- `run.py`: Punto de entrada.

## Contribución

Haz fork, crea una rama, commit y pull request.