from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

_engine = None
_SessionLocal = None
Base = declarative_base()


def init_engine(database_uri: str):
    global _engine
    if _engine is None:
        _engine = create_engine(database_uri, pool_pre_ping=True)
    return _engine


def get_engine():
    return _engine


def init_session():
    global _SessionLocal
    if _SessionLocal is None:
        _SessionLocal = sessionmaker(bind=_engine, autoflush=False, autocommit=False)
    return _SessionLocal


def get_session():
    if _SessionLocal is None:
        raise RuntimeError('Session factory not initialized. Call init_session() after init_engine().')
    return _SessionLocal()