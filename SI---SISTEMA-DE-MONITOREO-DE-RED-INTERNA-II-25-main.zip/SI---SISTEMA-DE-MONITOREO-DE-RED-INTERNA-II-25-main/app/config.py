import os
from dotenv import load_dotenv

# Carga variables del archivo .env si existe
load_dotenv()

class Config:
    SECRET_KEY = os.getenv('SECRET_KEY', 'dev-secret-change-me')

    # URL de conexión a MySQL (ajusta usuario, password, host y puerto)
    SQLALCHEMY_DATABASE_URI = os.getenv(
        'DATABASE_URL',
        'mysql+pymysql://root:password@localhost:3306/base_monitoreo'
    )

    # Campo de username y password de la tabla usuarios (por si difieren)
    USER_TABLE = os.getenv('USER_TABLE', 'usuarios')
    USERNAME_FIELD = os.getenv('USERNAME_FIELD', 'username')
    PASSWORD_FIELD = os.getenv('PASSWORD_FIELD', 'password')