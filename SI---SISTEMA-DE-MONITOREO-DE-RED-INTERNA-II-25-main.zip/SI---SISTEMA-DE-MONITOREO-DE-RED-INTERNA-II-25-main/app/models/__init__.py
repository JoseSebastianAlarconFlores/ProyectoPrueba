# Importar todos los modelos para que estén disponibles
from .alertas import Alertas
from .dispositivos import Dispositivos
from .eventos import Eventos
from .grupos_dispositivo import GruposDispositivo
from .notificaciones import Notificaciones
from .permisos_rol import PermisosRol
from .reportes import Reportes
from .roles import Roles
from .usuarios import Usuarios

__all__ = [
    'Alertas',
    'Dispositivos',
    'Eventos',
    'GruposDispositivo',
    'Notificaciones',
    'PermisosRol',
    'Reportes',
    'Roles',
    'Usuarios'
]