from sqlalchemy import Column, Integer, String, Enum, DateTime, ForeignKey
from sqlalchemy.orm import declarative_base

Base = declarative_base()

class Dispositivos(Base):
    __tablename__ = 'dispositivos'

    id = Column(Integer, primary_key=True, autoincrement=True)
    nombre = Column(String(50), nullable=False)
    tipo = Column(Enum('Servidor', 'Switch', 'Wifi'), nullable=False)
    ip = Column(String(45), nullable=True, unique=True)
    ubicacion = Column(String(100), nullable=True)
    estado = Column(Enum('Activo', 'Inactivo', 'Mantenimiento'), nullable=True, server_default="'Activo'")
    fecha_creacion = Column(DateTime, nullable=True, server_default='current_timestamp()')
    grupos_dispositivo_id = Column(Integer, ForeignKey('grupos_dispositivo.id'), nullable=False)