from sqlalchemy import Column, Integer, String, Enum, DateTime, ForeignKey
from sqlalchemy.orm import declarative_base

Base = declarative_base()

class Alertas(Base):
    __tablename__ = 'alertas'

    id = Column(Integer, primary_key=True, autoincrement=True)
    tipo = Column(String(100), nullable=False)
    estado = Column(Enum('Activo', 'Pendiente', 'Resuelto', 'Ignorado'), nullable=True, server_default="'Activo'")
    fecha_hora = Column(DateTime, nullable=True, server_default='current_timestamp()')
    dispositivos_id = Column(Integer, ForeignKey('dispositivos.id'), nullable=False)