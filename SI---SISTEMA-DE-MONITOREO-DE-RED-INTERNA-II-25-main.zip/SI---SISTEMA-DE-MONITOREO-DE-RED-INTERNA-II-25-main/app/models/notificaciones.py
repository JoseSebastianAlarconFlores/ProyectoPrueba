from sqlalchemy import Column, Integer, String, Enum, DateTime, ForeignKey
from sqlalchemy.orm import declarative_base

Base = declarative_base()

class Notificaciones(Base):
    __tablename__ = 'notificaciones'

    id = Column(Integer, primary_key=True, autoincrement=True)
    tipo_notificacion = Column(Enum('Alerta', 'Reporte'), nullable=False)
    contenido = Column(String(200), nullable=False)
    fecha_hora = Column(DateTime, nullable=True, server_default='current_timestamp()')
    alertas_id = Column(Integer, ForeignKey('alertas.id'), nullable=True)
    reportes_id = Column(Integer, ForeignKey('reportes.id'), nullable=True)