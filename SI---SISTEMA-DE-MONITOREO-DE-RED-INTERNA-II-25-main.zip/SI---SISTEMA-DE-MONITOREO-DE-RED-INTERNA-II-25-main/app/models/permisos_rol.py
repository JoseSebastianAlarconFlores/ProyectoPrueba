from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import declarative_base

Base = declarative_base()

class PermisosRol(Base):
    __tablename__ = 'permisos_rol'

    id = Column(Integer, primary_key=True, autoincrement=True)
    permiso = Column(String(50), nullable=False)
    roles_id = Column(Integer, ForeignKey('roles.id'), nullable=False)