from sqlalchemy import Column, Integer, DateTime, ForeignKey
from sqlalchemy.orm import declarative_base

Base = declarative_base()

class Reportes(Base):
    __tablename__ = 'reportes'

    id = Column(Integer, primary_key=True, autoincrement=True)
    rango_inicio = Column(DateTime, nullable=False)
    rango_fin = Column(DateTime, nullable=False)
    generado_en = Column(DateTime, nullable=True, server_default='current_timestamp()')
    usuarios_id = Column(Integer, ForeignKey('usuarios.id'), nullable=False)