from sqlalchemy import Column, Integer, String, Enum
from sqlalchemy.orm import declarative_base

Base = declarative_base()

class GruposDispositivo(Base):
    __tablename__ = 'grupos_dispositivo'

    id = Column(Integer, primary_key=True, autoincrement=True)
    categoria = Column(Enum('Servidores', 'Dispositivos de Red'), nullable=False)
    descripcion = Column(String(150), nullable=True)