from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.orm import declarative_base

Base = declarative_base()

class Usuarios(Base):
    __tablename__ = 'usuarios'

    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String(50), nullable=False, unique=True)
    nombre = Column(String(30), nullable=False)
    apellido_paterno = Column(String(30), nullable=False)
    apellido_materno = Column(String(30), nullable=True)
    email = Column(String(100), nullable=False, unique=True)
    password = Column(String(255), nullable=False)
    creado_en = Column(DateTime, nullable=True, server_default='current_timestamp()')
    actualizado_en = Column(DateTime, nullable=True, server_default='current_timestamp()', onupdate='current_timestamp()')
    telefono = Column(String(20), nullable=True)
    roles_id = Column(Integer, ForeignKey('roles.id'), nullable=False)