from sqlalchemy import Column, Integer, DateTime, ForeignKey
from sqlalchemy.orm import declarative_base

Base = declarative_base()

class Eventos(Base):
    __tablename__ = 'eventos'

    id = Column(Integer, primary_key=True, autoincrement=True)
    fecha_hora = Column(DateTime, nullable=True, server_default='current_timestamp()')
    latencia_ms = Column(Integer, nullable=True)
    dispositivos_id = Column(Integer, ForeignKey('dispositivos.id'), nullable=False)