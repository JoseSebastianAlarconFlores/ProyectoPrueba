from ..db import get_engine
from ..config import Config
from sqlalchemy import text
from werkzeug.security import check_password_hash


class AuthService:
    @staticmethod
    def login(username: str, password: str):
        if not username or not password:
            return False, 'Usuario y contraseña son obligatorios.'
        engine = get_engine()
        if engine is None:
            return False, 'Motor de base de datos no inicializado.'

        # Construye consulta segura con parámetros
        user_table = Config.USER_TABLE
        username_field = Config.USERNAME_FIELD
        password_field = Config.PASSWORD_FIELD
        query = text(f"""
            SELECT * FROM {user_table}
            WHERE {username_field} = :username
            LIMIT 1
        """)
        with engine.connect() as conn:
            row = conn.execute(query, {"username": username}).mappings().first()
            if not row:
                return False, 'Credenciales inválidas.'

            # Si el password está hasheado (p.ej. pbkdf2:sha256$...), usa check_password_hash
            db_password = row.get(password_field)
            if db_password and (db_password.startswith('pbkdf2:') or db_password.startswith('scrypt:') or db_password.startswith('argon2:')):
                if not check_password_hash(db_password, password):
                    return False, 'Credenciales inválidas.'
            else:
                # Comparación simple si no está hasheado
                if db_password != password:
                    return False, 'Credenciales inválidas.'

            # Normaliza respuesta para sesión
            user_id = row.get('id') if 'id' in row else row.get('ID') or row.get('id_usuario') or row.get('user_id')
            return True, {"id": user_id, "username": row.get(username_field)}