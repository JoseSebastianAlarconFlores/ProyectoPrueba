from ..db import get_engine
from ..config import Config
from sqlalchemy import text
from werkzeug.security import generate_password_hash


class UserService:
    @staticmethod
    def get_all_users():
        engine = get_engine()
        if engine is None:
            raise RuntimeError('Motor de base de datos no inicializado.')
        user_table = Config.USER_TABLE
        query = text(f"""
            SELECT u.*, r.nombre_rol
            FROM {user_table} u
            LEFT JOIN roles r ON u.roles_id = r.id
        """)
        with engine.connect() as conn:
            rows = conn.execute(query).mappings().all()
            # Procesar filas para ocultar passwords largos y reemplazar roles_id por nombre_rol
            processed_rows = []
            for row in rows:
                row_dict = dict(row)
                # Ocultar password largo
                if 'password' in row_dict and row_dict['password']:
                    pwd = str(row_dict['password'])
                    if len(pwd) > 10:
                        row_dict['password'] = pwd[:10] + '...'
                # Reemplazar roles_id por Rol (nombre_rol)
                if 'nombre_rol' in row_dict:
                    row_dict['Rol'] = row_dict.pop('nombre_rol')
                # Mantener roles_id para edición
                # row_dict.pop('roles_id', None)
                processed_rows.append(row_dict)
            return processed_rows

    @staticmethod
    def create_user(username, password, nombre, apellido_paterno, apellido_materno, email, telefono, roles_id):
        engine = get_engine()
        if engine is None:
            raise RuntimeError('Motor de base de datos no inicializado.')
        user_table = Config.USER_TABLE
        hashed_password = generate_password_hash(password)
        query = text(f"INSERT INTO {user_table} (username, password, nombre, apellido_paterno, apellido_materno, email, telefono, roles_id) VALUES (:username, :password, :nombre, :apellido_paterno, :apellido_materno, :email, :telefono, :roles_id)")
        with engine.connect() as conn:
            conn.execute(query, {
                'username': username,
                'password': hashed_password,
                'nombre': nombre,
                'apellido_paterno': apellido_paterno,
                'apellido_materno': apellido_materno,
                'email': email,
                'telefono': telefono,
                'roles_id': roles_id
            })
            conn.commit()

    @staticmethod
    def update_user(user_id, username=None, password=None, nombre=None, apellido_paterno=None, apellido_materno=None, email=None, telefono=None, roles_id=None):
        engine = get_engine()
        if engine is None:
            raise RuntimeError('Motor de base de datos no inicializado.')
        user_table = Config.USER_TABLE
        updates = []
        params = {'id': user_id}
        if username:
            updates.append("username = :username")
            params['username'] = username
        if password:
            updates.append("password = :password")
            params['password'] = generate_password_hash(password)
        if nombre:
            updates.append("nombre = :nombre")
            params['nombre'] = nombre
        if apellido_paterno:
            updates.append("apellido_paterno = :apellido_paterno")
            params['apellido_paterno'] = apellido_paterno
        if apellido_materno:
            updates.append("apellido_materno = :apellido_materno")
            params['apellido_materno'] = apellido_materno
        if email:
            updates.append("email = :email")
            params['email'] = email
        if telefono:
            updates.append("telefono = :telefono")
            params['telefono'] = telefono
        if roles_id:
            updates.append("roles_id = :roles_id")
            params['roles_id'] = roles_id
        if not updates:
            return
        query = text(f"UPDATE {user_table} SET {', '.join(updates)} WHERE id = :id")
        with engine.connect() as conn:
            conn.execute(query, params)
            conn.commit()

    @staticmethod
    def delete_user(user_id):
        engine = get_engine()
        if engine is None:
            raise RuntimeError('Motor de base de datos no inicializado.')
        user_table = Config.USER_TABLE
        query = text(f"DELETE FROM {user_table} WHERE id = :id")
        with engine.connect() as conn:
            conn.execute(query, {'id': user_id})
            conn.commit()

    @staticmethod
    def get_roles():
        engine = get_engine()
        if engine is None:
            raise RuntimeError('Motor de base de datos no inicializado.')
        query = text("SELECT id, nombre_rol FROM roles")
        with engine.connect() as conn:
            rows = conn.execute(query).mappings().all()
            return [dict(row) for row in rows]