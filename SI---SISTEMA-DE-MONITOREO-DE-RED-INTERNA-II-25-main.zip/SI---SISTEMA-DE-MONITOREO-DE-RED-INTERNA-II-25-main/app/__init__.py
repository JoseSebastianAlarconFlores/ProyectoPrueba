from flask import Flask
from flask import redirect, url_for
from .config import Config
from .db import init_engine, init_session


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # DB engine and session
    init_engine(Config.SQLALCHEMY_DATABASE_URI)
    init_session()

    # Register blueprints
    from .controllers.auth_controller import auth_bp
    from .controllers.user_controller import user_bp
    app.register_blueprint(auth_bp)
    app.register_blueprint(user_bp)

    @app.route('/')
    def index():
        return redirect(url_for('auth.login'))

    return app