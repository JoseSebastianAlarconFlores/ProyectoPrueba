from flask import Blueprint, render_template, session, redirect, url_for, request, flash
from ..services.user_service import UserService

user_bp = Blueprint('users', __name__, url_prefix='/users')


def _login_required():
    if not session.get('user_id'):
        return False
    return True


@user_bp.route('/')
def list_users():
    if not _login_required():
        return redirect(url_for('auth.login'))
    users = UserService.get_all_users()
    roles = UserService.get_roles()
    return render_template('users.html', users=users, roles=roles)


@user_bp.route('/create', methods=['POST'])
def create_user():
    if not _login_required():
        return redirect(url_for('auth.login'))
    username = request.form.get('username')
    password = request.form.get('password')
    nombre = request.form.get('nombre')
    apellido_paterno = request.form.get('apellido_paterno')
    apellido_materno = request.form.get('apellido_materno')
    email = request.form.get('email')
    telefono = request.form.get('telefono')
    roles_id = request.form.get('roles_id')
    if username and password and nombre and apellido_paterno and email and roles_id:
        try:
            UserService.create_user(username, password, nombre, apellido_paterno, apellido_materno, email, telefono, int(roles_id))
            flash('Usuario creado exitosamente.', 'success')
        except Exception as e:
            flash(f'Error al crear usuario: {str(e)}', 'error')
    else:
        flash('Todos los campos requeridos deben ser completados.', 'error')
    return redirect(url_for('users.list_users'))


@user_bp.route('/update', methods=['POST'])
def update_user():
    if not _login_required():
        return redirect(url_for('auth.login'))
    user_id = int(request.form.get('user_id'))
    username = request.form.get('username')
    password = request.form.get('password')
    nombre = request.form.get('nombre')
    apellido_paterno = request.form.get('apellido_paterno')
    apellido_materno = request.form.get('apellido_materno')
    email = request.form.get('email')
    telefono = request.form.get('telefono')
    roles_id = request.form.get('roles_id')
    try:
        UserService.update_user(user_id, username=username, password=password, nombre=nombre, apellido_paterno=apellido_paterno, apellido_materno=apellido_materno, email=email, telefono=telefono, roles_id=int(roles_id) if roles_id else None)
        flash('Usuario actualizado exitosamente.', 'success')
    except Exception as e:
        flash(f'Error al actualizar usuario: {str(e)}', 'error')
    return redirect(url_for('users.list_users'))


@user_bp.route('/delete', methods=['POST'])
def delete_user():
    if not _login_required():
        return redirect(url_for('auth.login'))
    user_id = int(request.form.get('user_id'))
    try:
        UserService.delete_user(user_id)
        flash('Usuario eliminado exitosamente.', 'success')
    except Exception as e:
        flash(f'Error al eliminar usuario: {str(e)}', 'error')
    return redirect(url_for('users.list_users'))